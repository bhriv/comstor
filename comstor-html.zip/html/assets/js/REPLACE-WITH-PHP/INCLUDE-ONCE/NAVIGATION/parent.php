<div class="one columns nav-bar">
    <nav class="top-nav" style="z-index:2;">
        <ul>
            <!-- <li class=""><a href="/home" class="ttip" data-tooltip="Manager Dashboard"><i class="icon-home"></i></a></li>-->
            <li class="">
                <a class="ttip" data-tooltip="Dashboard Home" href="/home"><i class="icon-home"></i></a>
            </li>
            <li class=" active">
                <a class="ttip" data-tooltip="Reports" href="/reports"><i class="icon-shuffle"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Messages" href="/messages/home"><i class="icon-chat"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Settings" href="/profile/"><i class="icon-cog"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Stats" href="/stats/home"><i class="icon-chart-bar"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Users" href="/users"><i class="icon-users"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Videos" href="/videos"><i class="icon-video"></i></a>
            </li>
            <li class="">
                <a class="ttip" data-tooltip="Help" href="/help"><i class="icon-help-circled"></i></a>
            </li>
        </ul>
    </nav>
</div>
<script>cc('parent.php content loaded','ready');</script>