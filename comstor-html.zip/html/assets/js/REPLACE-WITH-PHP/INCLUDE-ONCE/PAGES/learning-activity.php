<?	// Learning Activity ?>
Learning Activity - TOTARA
<section class="report_display_switch" id="flurry_reports" style="display:block;">
    <!-- TOTARA -->
    <span id="pull_student_data">pull_student_data()</span> 
     <h3><i class="fa fa-bar-chart"></i> Totara Activity</h3>
	<table class="tablesorter sortable">
	    <thead>
	        <tr>
	            <th>ID</th>   
	            <th>Student</th>   
	            <th>Action</th>
	            <th>Course ID</th>   
	            <th>Object Table</th>
	            <th>Object ID</th> 
	            <th>Date/Time</th>           
	        </tr>
	    </thead>
	    <tbody id="tbody_activity_result"></tbody>
	</table>
</section>